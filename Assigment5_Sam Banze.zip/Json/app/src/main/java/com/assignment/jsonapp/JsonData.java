package com.assignment.jsonapp;



public class JsonData {

    private String[] classes;
    private String room;
    private String subject;
    private String teacherAbbreviation;
    private String start;
    private String end;
    private String uid;
    private int hoursMask;
    private String description;
    private String updatedAt;

    public JsonData(String[] classes, String room, String subject, String teacherAbbreviation, String start, String end, String uid, int hoursMask, String description, String updatedAt) {
        this.classes = classes;
        this.room = room;
        this.subject = subject;
        this.teacherAbbreviation = teacherAbbreviation;
        this.start = start;
        this.end = end;
        this.uid = uid;
        this.hoursMask = hoursMask;
        this.description = description;
        this.updatedAt = updatedAt;
    }

    public String[] getClasses() {
        return classes;
    }

    public void setClasses(String[] classes) {
        this.classes = classes;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTeacherAbbreviation() {
        return teacherAbbreviation;
    }

    public void setTeacherAbbreviation(String teacherAbbreviation) {
        this.teacherAbbreviation = teacherAbbreviation;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getHoursMask() {
        return hoursMask;
    }

    public void setHoursMask(int hoursMask) {
        this.hoursMask = hoursMask;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}
