package com.assignment.jsonapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<JsonData> list;
    TextView textViewTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView)findViewById(R.id.listview);
        textViewTitle = (TextView)findViewById(R.id.textview);

        list = new ArrayList<>();

        getData();

        JsonDataAdapter adapter = new JsonDataAdapter(this,list);
        listView.setAdapter(adapter);
        Log.d("TAG_","L:ength : "+String.valueOf(list.size()));
    }

    private void getData()
    {
        String allData = loadJSONFromAsset(this,"json");

        JSONArray jsonArray = null;
        try {

            JSONObject dataObj = new JSONObject(allData);
            String title = dataObj.getString("title");
            textViewTitle.setText(title);

            String datas = dataObj.getString("data");
            jsonArray = new JSONArray(datas);
            for(int i = 0; i < jsonArray.length();i++)
            {
                JSONObject object = jsonArray.getJSONObject(i);

                String subject = object.getString("subject");
                String room = object.getString("room");
                String teacherAbbreviation = object.getString("teacherAbbreviation");
                String start = object.getString("start");
                String end = object.getString("end");
                String uid = object.getString("uid");
                int hoursMask = object.getInt("hoursMask");
                String description = object.getString("description");

                JSONArray jsonArrayClasses = new JSONArray(String.valueOf(object.get("classes")));
                String[] classes = new String[jsonArrayClasses.length()];
                for(int j = 0; j < jsonArrayClasses.length();j++)
                {
                    classes[j] = String.valueOf(jsonArrayClasses.get(j));
                }
                //String[] classes = (String[]) object.get("classes");
                String updatedAt = object.getString("updatedAt");

                JsonData jsonData = new JsonData(classes,room,subject,teacherAbbreviation,start,end,uid,hoursMask,description,
                        updatedAt);

                list.add(jsonData);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("TAG_",e.getMessage());
        }
    }

    private static String loadJSONFromAsset(Context context,String assetName) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(assetName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}
