package com.assignment.jsonapp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;



public class JsonDataAdapter extends ArrayAdapter<JsonData> {

    private ArrayList<JsonData> list;
    private final Activity context;
    private static LayoutInflater inflator = null;

    public JsonDataAdapter(Activity context, ArrayList<JsonData> list) {
        super(context, R.layout.layout_data, list);
        this.context = context;
        this.list = list;
        inflator = (LayoutInflater)this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public Activity getActivity()
    {
        return this.context;
    }

    public ArrayList<JsonData> getList()
    {
        return this.list;
    }

    public static class ViewHolder{
        public TextView textView_classes;
        public TextView textView_room;
        public TextView textView_subject;
        public TextView textView_teacherAbbreviation;
        public TextView textView_start;
        public TextView textView_end;
        public TextView textView_uid;
        public TextView textView_hoursMask;
        public TextView textView_description;
        public TextView textView_updatedAt;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        ViewHolder holder;

        if(convertView==null){
            view = inflator.inflate(R.layout.layout_data, null);
            /****** View Holder Object to contain tabitem.xml file elements ******/

            holder = new ViewHolder();
            holder.textView_subject = (TextView)view.findViewById(R.id.textview_subject);
            holder.textView_classes = (TextView)view.findViewById(R.id.textview_classes);
            holder.textView_description = (TextView)view.findViewById(R.id.textview_description);
            holder.textView_start = (TextView)view.findViewById(R.id.textview_start);
            holder.textView_end = (TextView)view.findViewById(R.id.textview_end);
            holder.textView_uid = (TextView)view.findViewById(R.id.textview_uid);
            holder.textView_hoursMask = (TextView)view.findViewById(R.id.textview_hoursMask);
            holder.textView_room = (TextView)view.findViewById(R.id.textview_room);
            holder.textView_teacherAbbreviation = (TextView)view.findViewById(R.id.textview_teacherAbbreviation);
            holder.textView_updatedAt = (TextView)view.findViewById(R.id.textview_updatedAt);

            /************  Set holder with LayoutInflater ************/
            view.setTag( holder );
        }
        else
            holder=(ViewHolder)view.getTag();

        holder.textView_subject.setText(list.get(position).getSubject());

        holder.textView_classes.setText("");
        String[] classes = list.get(position).getClasses();
        for (int i = 0;i < classes.length;i++)
        {
            String item = "";
            if(i < classes.length-1)
                item += ", ";
            item += classes[i];
            holder.textView_classes.setText(holder.textView_classes.getText()+item);
        }

        holder.textView_description.setText(list.get(position).getDescription());
        holder.textView_start.setText(list.get(position).getStart());
        holder.textView_end.setText(list.get(position).getEnd());
        holder.textView_uid.setText(list.get(position).getUid());
        holder.textView_hoursMask.setText(String.valueOf(list.get(position).getHoursMask()));
        holder.textView_room.setText(list.get(position).getRoom());
        holder.textView_teacherAbbreviation.setText(list.get(position).getTeacherAbbreviation());
        holder.textView_updatedAt.setText(list.get(position).getUpdatedAt());

        return view;
    }
}
